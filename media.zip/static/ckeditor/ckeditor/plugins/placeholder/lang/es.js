﻿/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("placeholder","es",{title:"Propiedades del Marcador de Posición",toolbar:"Crear Marcador de Posición",name:"Nombre del Marcador de Posición",invalidName:"El marcador de posición no puede estar vacío y no puede contener ninguno de los siguientes caracteres: [, ], <, >",pathName:"marcador de posición"});